// Cole aqui os dados do seu projeto Supabase.
const SUPABASE_URL = 'COLE_AQUI_A_URL_DO_SEU_PROJETO';
const SUPABASE_ANON_KEY = 'COLE_AQUI_A_CHAVE_ANON_PUBLICA';
const WHATSAPP = '5567999726408';
